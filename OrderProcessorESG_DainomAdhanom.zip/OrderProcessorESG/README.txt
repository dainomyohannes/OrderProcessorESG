# Java Order Processor – ESG Assignment
Author: Dainom Adhanom

## How to Run
1. Ensure Java 17+ is installed.
2. Place `orders.json` in the same directory as compiled `.class` files.
3. Run using:
   java -cp .:jackson-core-2.15.2.jar:jackson-databind-2.15.2.jar:jackson-annotations-2.15.2.jar Main

## What It Does
- Parses a JSON file with order data
- Calculates total cost and item count per order
- Displays a summary of *shipped* orders and total revenue
