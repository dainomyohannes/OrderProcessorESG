import java.util.*;
import java.io.*;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

class Item {
    public String product;
    public int quantity;
    public double price;
}

class Order {
    public String orderId;
    public String customer;
    public List<Item> items;
    public String status;
}

public class Main {
    public static void main(String[] args) throws Exception {
        // Load JSON file
        ObjectMapper mapper = new ObjectMapper();
        List<Order> orders = mapper.readValue(new File("orders.json"), new TypeReference<List<Order>>() {});

        int totalShipped = 0;
        double shippedRevenue = 0.0;

        for (Order order : orders) {
            int itemCount = 0;
            double totalPrice = 0.0;

            for (Item item : order.items) {
                itemCount += item.quantity;
                totalPrice += item.quantity * item.price;
            }

            System.out.printf("Order %s | Customer: %s | Items: %d | Total: $%.2f\n",
                    order.orderId, order.customer, itemCount, totalPrice);

            if ("shipped".equalsIgnoreCase(order.status)) {
                totalShipped++;
                shippedRevenue += totalPrice;
            }
        }

        System.out.printf("\nSummary: %d shipped orders | Revenue: $%.2f\n", totalShipped, shippedRevenue);
    }
}
